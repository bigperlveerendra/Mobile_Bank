package com.example.mobilebankingapp;

public class Config {
	static String ipAdress;
	public static void setIP(String IP)
	{
		ipAdress=IP;
	}
	public static String getIP()
	{
		return ipAdress;
	}

}
