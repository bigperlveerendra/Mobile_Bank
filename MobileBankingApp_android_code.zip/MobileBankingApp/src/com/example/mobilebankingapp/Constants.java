package com.example.mobilebankingapp;
public class Constants {

	// encryption/decryption
	public static String AES_KEY = "0366D8637F9C6B21";      
	public static byte[] IV_VECTOR = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};


	}

